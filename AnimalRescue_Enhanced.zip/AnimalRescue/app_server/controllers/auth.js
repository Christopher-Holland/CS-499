const bcrypt = require('bcrypt');
const crypto = require('crypto');
const User = require('../models/User');
const { validationResult } = require('express-validator');

// =================== LOGIN ===================

// GET /auth/login
const loginPage = (req, res) => {
  res.render('login', { title: 'Login to Animal Rescue Inventory' });
};

// POST /auth/login
const login = async (req, res) => {
  const { username, password } = req.body;

  try {
    const foundUser = await User.findOne({ username });
    if (!foundUser) {
      return res.render('login', { title: 'Login', error: 'Invalid username or password' });
    }

    const validPassword = await bcrypt.compare(password, foundUser.password);
    if (!validPassword) {
      return res.render('login', { title: 'Login', error: 'Invalid username or password' });
    }

    req.session.user = foundUser.username;
    res.redirect('/animal');

  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

// =================== LOGOUT ===================
const logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect('/auth/login');
  });
};

// =================== REGISTER ===================
const register = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('register', { 
      title: 'Register New Account',
      errors: errors.array(),
      data: req.body
    });
  }

  const { username, email, password } = req.body;

  try {
    const existingUser = await User.findOne({ $or: [{ username }, { email }] });
    if (existingUser) {
      return res.render('register', { 
        title: 'Register New Account', 
        error: 'User already exists',
        data: req.body
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      username,
      email,
      password: hashedPassword
    });

    await newUser.save();
    return res.redirect('/auth/login');

  } catch (err) {
    console.error(err);
    return res.status(500).send('Server error');
  }
};

// =================== FORGOT PASSWORD ===================
const forgotPage = (req, res) => {
  res.render('forgot', { title: 'Forgot Password' });
};

const forgot = async (req, res) => {
  const { email } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.render('forgot', { 
        title: 'Forgot Password', 
        error: 'No account with that email found.' 
      });
    }

    const token = crypto.randomBytes(20).toString('hex');
    user.resetPasswordToken = token;
    user.resetPasswordExpires = Date.now() + 3600000; // 1 hour

    await user.save();

    res.redirect(`/auth/reset/${token}`);
    console.log(`Password reset link: http://${req.headers.host}/auth/reset/${token}`);

  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

// =================== RESET PASSWORD ===================
const resetPage = async (req, res) => {
  try {
    const user = await User.findOne({
      resetPasswordToken: req.params.token,
      resetPasswordExpires: { $gt: Date.now() }
    });

    if (!user) {
      return res.render('forgot', { 
        title: 'Forgot Password', 
        error: 'Password reset token is invalid or has expired.' 
      });
    }

    res.render('reset', { title: 'Reset Password', token: req.params.token });

  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

const resetPassword = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('reset', { 
      title: 'Reset Password',
      token: req.params.token,
      errors: errors.array()
    });
  }

  try {
    const user = await User.findOne({
      resetPasswordToken: req.params.token,
      resetPasswordExpires: { $gt: Date.now() }
    });

    if (!user) {
      return res.render('forgot', { 
        title: 'Forgot Password', 
        error: 'Password reset token is invalid or has expired.' 
      });
    }

    user.password = await bcrypt.hash(req.body.password, 10);
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    res.redirect('/auth/login');

  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

// =================== EXPORTS ===================
module.exports = {
  loginPage,
  login,
  logout,
  register,
  forgotPage,
  forgot,
  resetPage,
  resetPassword
};