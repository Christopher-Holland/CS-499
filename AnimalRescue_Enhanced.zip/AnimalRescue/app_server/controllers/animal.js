const Animal = require('../models/Animal');

// Helper function to convert string to title case
function toTitleCase(str) {
  return str.replace(/\w\S*/g, (txt) =>
    txt.charAt(0).toUpperCase() + txt.substring(1).toLowerCase()
  );
}

// GET all animals
const getAllAnimals = async (req, res) => {
  try {
    const query = {};

    if (req.query.name) {
      query.name = { $regex: req.query.name, $options: 'i' }; // Partial match, case-insensitive
    }

    if (req.query.type) {
      query.type = toTitleCase(req.query.type); // Normalize to match stored capitalization
    }

    if (req.query.healthStatus) {
      query.healthStatus = toTitleCase(req.query.healthStatus); // Just in case
    }

    const animals = await Animal.find(query);
    res.render('animal', {
      title: 'Animal Dashboard',
      animals,
      filters: req.query
    });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching animals');
  }
};

// Helper function to capitalize words - first letter of each word
const capitalizeWords = str => str.replace(/\b\w/g, char => char.toUpperCase());
// POST new animal
const createAnimal = async (req, res) => {
  try {
    let { type, name, breed, age, healthStatus, intakeDate } = req.body;

    // Capitalize type, name, and breed
    type = capitalizeWords(type.trim());
    name = capitalizeWords(name.trim());
    breed = capitalizeWords(breed.trim());

    const lastAnimal = await Animal.findOne().sort({ animalID: -1 });
    const lastIdNum = lastAnimal && !isNaN(parseInt(lastAnimal.animalID))
      ? parseInt(lastAnimal.animalID)
      : 0;
    const newId = lastIdNum + 1;

    const animal = new Animal({
      type: toTitleCase(type),
      name: toTitleCase(name),
      breed: toTitleCase(breed),
      age,
      healthStatus,
      intakeDate,
      animalID: newId
    });

    await animal.save();
    res.redirect('/animal');
  } catch (err) {
    console.error('Error adding animal:', err);
    res.status(500).send('Error adding animal');
  }
};

// GET one animal by ID
const getAnimalById = async (req, res) => {
  try {
    const animal = await Animal.findById(req.params.id);
    if (!animal) {
      return res.status(404).send('Animal not found');
    }

    res.render('edit-animal', {
      title: 'Edit Animal',
      animal
    });
  } catch (err) {
    console.error('Error fetching animal:', err);
    res.status(500).send('Server error');
  }
};

// POST update animal by ID
const updateAnimal = async (req, res) => {
  try {
    const { type, name, breed, age, healthStatus, intakeDate, reserved } = req.body;
    await Animal.findByIdAndUpdate(req.params.id, {
      type: toTitleCase(type),
      name: toTitleCase(name),
      breed: toTitleCase(breed),
      age,
      healthStatus,
      intakeDate: new Date(intakeDate),
      reserved: reserved === 'on'
    });
    res.redirect('/animal'); // redirect to animal list after update
  } catch (err) {
    res.status(500).send('Error updating animal');
  }
};

// POST delete animal by ID
const deleteAnimal = async (req, res) => {
  try {
    await Animal.findByIdAndDelete(req.params.id);
    res.redirect('/animal'); // redirect to animal list after deletion
  } catch (err) {
    res.status(500).send('Error deleting animal');
  }
};

module.exports = {
  getAllAnimals,
  createAnimal,
  getAnimalById,
  updateAnimal,
  deleteAnimal
};