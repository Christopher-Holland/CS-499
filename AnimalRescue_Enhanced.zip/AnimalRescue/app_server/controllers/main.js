const animalStore = require('../../data/animalStore');

const index = (req, res) => {
  const animals = animalStore.getAllAnimals();

  res.render('animal', {
    title: 'Animal Rescue Inventory',
    animals: animals
  });
};

module.exports = {
  index
};