const mongoose = require('mongoose');

const animalSchema = new mongoose.Schema({
    animalID: { type: Number, required: true, unique: true }, // unique number ID
    type: { type: String, required: true },
    name: { type: String, required: true },
    breed: { type: String, required: true },
    age: { type: Number, required: true },
    healthStatus: { type: String, required: true },
    intakeDate: { type: Date, default: Date.now },
    reserved: { type: Boolean, default: false }
});

module.exports = mongoose.model('Animal', animalSchema);