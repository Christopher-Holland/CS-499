const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const authController = require('../controllers/auth');

// Validation rules for registration
const registerValidation = [
  body('username')
    .trim()
    .isLength({ min: 3, max: 20 })
    .withMessage('Username must be between 3 and 20 characters')
    .matches(/^[a-zA-Z0-9_.]+$/)
    .withMessage('Username can only contain letters, numbers, underscores, and dots'),
  body('email')
    .isEmail()
    .withMessage('Enter a valid email address')
    .normalizeEmail(),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters long'),
  body('confirm')
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('Passwords do not match');
      }
      return true;
    }),
];

// Validation rules for password reset
const resetValidation = [
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters long'),
  body('confirm')
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('Passwords do not match');
      }
      return true;
    }),
];

// ================== ROUTES ==================

// Show login page
router.get('/login', authController.loginPage);

// Handle login form submission
router.post('/login', authController.login);

// Handle logout
router.get('/logout', authController.logout);

// Show registration page
router.get('/register', (req, res) => {
  res.render('register', { title: 'Register New Account' });
});

// Handle registration form submission WITH validation
router.post('/register', registerValidation, authController.register);

// Forgot password section
router.get('/forgot', authController.forgotPage);
router.post('/forgot', authController.forgot);

// Show reset password form
router.get('/reset/:token', authController.resetPage);

// Handle reset password submission WITH validation
router.post('/reset/:token', resetValidation, authController.resetPassword);

module.exports = router;