const express = require('express');
const router = express.Router();
const ctrlMain = require('../controllers/main');

function requireLogin(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/auth/login');
  }
  next();
}

router.get('/', ctrlMain.index);

module.exports = router;