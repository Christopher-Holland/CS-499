const express = require('express');
const router = express.Router();
const animalCtrl = require('../controllers/animal');

// GET all animals
router.get('/', animalCtrl.getAllAnimals);

// POST new animal (intake)
router.post('/intake', animalCtrl.createAnimal);

// POST update animal by ID
router.post('/update/:id', animalCtrl.updateAnimal);

// POST delete animal by ID
router.post('/delete/:id', animalCtrl.deleteAnimal);

// GET single animal by ID (optional, useful for update)
router.get('/:id', animalCtrl.getAnimalById);

module.exports = router;