const animals = new Map(); // Use a Map for fast ID-based lookup

function getAllAnimals() {
  return Array.from(animals.values());
}

function addAnimal(animal) {
  animals.set(animal.id, animal);
}

function reserveAnimal(id) {
  const animal = animals.get(id);
  if (animal) {
    animal.reserved = true;
  }
}

module.exports = {
  getAllAnimals,
  addAnimal,
  reserveAnimal
};