var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var handlebars = require('hbs');

var indexRouter = require('./app_server/routes/index');
var authRouter = require('./app_server/routes/auth');
// var usersRouter = require('./app_server/routes/users');
var animalRouter = require('./app_server/routes/animal');
// var animalController = require('./controllers/animal');

// MongoDB setup
const mongoose = require('mongoose');

// Register Handlebars helper for equality check
const hbs = require('hbs');
hbs.registerHelper('eq', function (a, b) {
  return a === b;
});
// Register Handlebars helper for date formatting
const moment = require('moment');
hbs.registerHelper('formatDate', function (date) {
  return moment(date).format('MM/DD/YYYY');
});
hbs.registerHelper('formatDateISO', function (date) {
  return moment(date).format('YYYY-MM-DD');
});

mongoose.connect('mongodb://localhost/animal_rescue')
  .then(() => console.log('Mongoose connected to animal_rescue database'))
  .catch(err => console.error('Connection error:', err));


mongoose.connection.on('connected', () => {
  console.log('Mongoose connected to animal_rescue database');
});

mongoose.connection.on('error', (err) => {
  console.error('Mongoose connection error:', err);
});

var app = express();

// View engine setup
app.set('views', path.join(__dirname, 'app_server/views'));
handlebars.registerPartials(__dirname + '/app_server/views/partials');
app.set('view engine', 'hbs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Session setup
const session = require('express-session');
app.use(session({ 
  secret: 'CS499AnimalRescue',
  resave: false,
  saveUninitialized: false
}));

// Authentication middleware
app.use((req, res, next) => {
  const publicRoutes = [
    '/auth/login',
    '/auth/logout',
    '/auth/register',
    '/auth/forgot',
    '/auth/reset'];
  const isPublic = publicRoutes.some(route => req.path.startsWith(route));

  if (!req.session.user && !isPublic) {
    console.log('Redirecting unauthenticated access to: ' + req.path); // DEBUG: Log the path being accessed
    return res.redirect('/auth/login');
  }
  next();
});

// Routes
app.use('/', indexRouter);
app.use('/auth', authRouter);
// app.use('/users', usersRouter);
app.use('/animal', animalRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;